# Complete artifact index

| Path | Status | Role |
| --- | --- | --- |
| 00_START_HERE.md | current | Entry guide / navigation |
| 01_Presentation/MLC_Consolidated_Presentation.pdf | current | Current talk and speaker notes |
| 01_Presentation/MLC_Consolidated_Presentation.pptx | current | Current talk and speaker notes |
| 01_Presentation/Slide_Overview.png | current | Current talk and speaker notes |
| 01_Presentation/Speaker_Notes.md | current | Current talk and speaker notes |
| 01_Presentation/Speaker_Notes.pdf | current | Current talk and speaker notes |
| 01_Presentation/Title_Slide.png | current | Current talk and speaker notes |
| 01_Presentation/layout_audit.json | current | Current talk and speaker notes |
| 02_Report/Artifact_Index.csv | current | Current report, inventory and validation |
| 02_Report/Artifact_Index.md | current | Current report, inventory and validation |
| 02_Report/MLC_Consolidated_Report.md | current | Current report, inventory and validation |
| 02_Report/MLC_Consolidated_Report.pdf | current | Current report, inventory and validation |
| 02_Report/Validation.json | current | Current report, inventory and validation |
| 02_Report/Validation_Log.txt | current | Current report, inventory and validation |
| 03_Project/.gitignore | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/MLC_Bayesian_DAG_updated.ipynb | original baseline; stored execution | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/MLC_Posterior_Predictive_Value.ipynb | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/MLC_RETRO_Followup.ipynb | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/MLC_Weights_SMR_Audit.ipynb | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/NOTEBOOK_ORDER.md | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/README.md | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/data/README.md | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/grading_results/assignment_inventory.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/grading_results/category_weights.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/grading_results/grading_config.json | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/grading_results/historical_assignment_mapping_audit.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/grading_results/weight_audit.json | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/actual_vs_predicted.png | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/all_43_actual_and_predicted_percentages.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/all_column_eligibility_manifest.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/cohort_sample_audit.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/complete_evidence_full.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/complete_evidence_grades_only.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/complete_evidence_uncertainty_diagnostics.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/expanded_full_DAG.dot | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/expanded_full_DAG.png | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/expanded_full_DAG.svg | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/expanded_student_features.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/fitted_DAG_parents.json | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/full_model_coefficients.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/interval_diagnostics.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/lms_deduplication_audit.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/missingness_by_cohort.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/reused_evaluation_metrics.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/run_provenance.json | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/selected_assessment_sources.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/selected_configuration.json | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/temporal_out_of_fold_predictions.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/temporal_validation_metrics.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/train_mean_baseline.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/training_correlations.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/mlc_results/validation_summary.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/ablation_mae.png | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/coefficient_posteriors.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/coefficient_posteriors.png | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/coefficients_by_context.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/data_availability.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/gibbs_trace.png | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/macro_metrics.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/mcmc_diagnostics.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/missingness_indicators_metrics.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/paired_gain_summary.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/paired_gains.png | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/paired_term_gains.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/precision_100_metrics.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/precision_1_metrics.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/prediction_shift_summary.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/provenance.json | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/respondents_only_metrics.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/sensitivity_gains.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/spring2026_probabilities.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/summer_exclusion.json | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/temporal_metrics.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_results/temporal_predictions.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/__init__.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/analysis.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/build_presentation.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/build_retro_addendum.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/cohort_policy.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/create_release.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/environment-freeze.txt | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/grading_weights.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/prepare_publication.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/requirements-presentation.txt | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/retro_followup.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/retro_report.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/weight_report.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/posterior_study/write_report.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/requirements.txt | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/retro_followup_results/model_benchmark_by_term.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/retro_followup_results/model_benchmark_macro.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/retro_followup_results/model_benchmark_predictions.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/retro_followup_results/model_comparison.png | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/retro_followup_results/retro_availability_by_week.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/retro_followup_results/retro_early_coverage.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/retro_followup_results/retro_gains.png | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/retro_followup_results/retro_macro_metrics.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/retro_followup_results/retro_metrics_by_term.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/retro_followup_results/retro_paired_gains.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/retro_followup_results/retro_predictions.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/retro_followup_results/retro_provenance.json | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/retro_followup_results/retro_response_features.csv | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/run_available_studies.sh | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/tests/test_grading_weights.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/tests/test_posterior_study.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 03_Project/tests/test_retro_followup.py | current | Runnable notebooks, source, tests, inputs and complete results |
| 04_Diagrams/Original_Fitted_DAG.dot | current | Original graph / labelled proposal |
| 04_Diagrams/Original_Fitted_DAG.png | current | Original graph / labelled proposal |
| 04_Diagrams/Original_Fitted_DAG.svg | current | Original graph / labelled proposal |
| 04_Diagrams/Proposed_Temporal_Structure.png | current | Original graph / labelled proposal |
| 04_Diagrams/Proposed_Temporal_Structure.svg | current | Original graph / labelled proposal |
| 04_Diagrams/README.md | current | Original graph / labelled proposal |
| 05_Archive/README.md | archive | Earlier versions / user reference context |
| INDEX.html | current | Entry guide / navigation |
