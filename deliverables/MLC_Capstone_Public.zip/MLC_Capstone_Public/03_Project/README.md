# Runnable public project

The current report and presentation are in ../02_Report/ and ../01_Presentation/. Four notebooks, the existing anonymized processed table, code, tests and all derived results are included. Uploaded source responses/workbooks and chat history are excluded.

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
bash run_available_studies.sh
```

The runner always executes the numeric study and all 14 tests. RETRO and workbook recomputation run only when the omitted inputs are provided locally at the paths documented in data/README.md. All derived result tables remain available even when those optional source files are absent. The original raw-data notebook still requires the missing historical source ZIP.

Optional presentation/report rebuild:

```bash
.venv/bin/python -m pip install -r posterior_study/requirements-presentation.txt
.venv/bin/python -m posterior_study.prepare_publication --output /path/to/new/public-package
```

Notebook order: original DAG; posterior predictive value; RETRO follow-up; weights/SMR audit. The latter three have saved executed outputs. The original execution is preserved, not newly reproduced from raw data. Summer/SMR is excluded. The remaining-work accounting is tested; actual historical remaining-work targets/models are not fitted. No causal effects are established.
