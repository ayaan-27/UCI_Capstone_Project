# Notebook order

1. MLC_Bayesian_DAG_updated.ipynb — original supplied execution, raw rerun blocked by missing historical ZIP.
2. MLC_Posterior_Predictive_Value.ipynb — executed posterior/source study using included processed rows.
3. MLC_RETRO_Followup.ipynb — executed result display; raw RETRO recomputation requires your local CSV.
4. MLC_Weights_SMR_Audit.ipynb — executed weight audit/arithmetic example; source workbook must be supplied locally for re-extraction.

These are explored retrospective analyses. Two-term RETRO MAEs and four-term numeric MAEs use different training/evaluation windows.
