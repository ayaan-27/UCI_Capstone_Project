# Source files excluded from GitHub

The public package contains no uploaded RETRO response CSV, workbook, prior chat, tokens, virtual environment or credential files. The derived processed table is in ../mlc_results/.

To recompute the optional raw-input stages locally, place your own original RETRO CSV at data/retro_uploaded.csv and your workbook at data/assignment_weights_uploaded.xlsx, or pass their paths to the modules. Original historical grade/source ZIP and release/revision snapshots remain unavailable. Existing derived tables and all 14 tests can be used without those uploads.
