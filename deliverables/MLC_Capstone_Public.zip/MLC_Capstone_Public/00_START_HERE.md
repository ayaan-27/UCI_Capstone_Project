# My Learning Coach — public GitHub package

## Start with the current deliverables

- 01_Presentation/MLC_Consolidated_Presentation.pptx — editable 19-slide talk (16 main + 3 appendix).
- 01_Presentation/MLC_Consolidated_Presentation.pdf — portable slide copy.
- 01_Presentation/Speaker_Notes.pdf — first-person rehearsal notes.
- 02_Report/MLC_Consolidated_Report.pdf — integrated research report.
- 03_Project/ — four notebooks, code, tests, processed input and complete derived tables/figures.
- 04_Diagrams/ — full original DAG and a labelled temporal proposal.

The main sample contains 191 non-summer students. All-source additions do not improve the larger-grade MAE; LMS alone has a modest no-grades signal. RETRO text gains are mixed. No causal or coaching effects are established. Weights are confirmed; remaining-work arithmetic is tested, but historical remaining-work targets/models are not fitted.

## What is omitted

Uploaded RETRO responses, the original workbook, pasted conversation/context and environment/credential files are not published. Supply your own raw files locally to recompute those stages. Their derived audit tables and the already-public anonymized processed feature table are included. The original historical source ZIP and score-availability history remain missing.

Open INDEX.html after unzipping for navigation. See 03_Project/README.md for installation and running. The public package passes the same 14 tests without the omitted raw inputs. MANIFEST.json hashes all shipped files.
