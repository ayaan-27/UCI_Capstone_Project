# Earlier versions

Earlier public project presentations and results remain in the GitHub repository and its history. They are not duplicated here. Uploaded reference files, source responses and pasted conversations are excluded. Use the consolidated report for the current interpretation.
